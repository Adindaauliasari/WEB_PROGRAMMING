<?php

include('pelangganScript.php');


$result = delete_data_pelanggan($_GET['id']);

if($result) {
    header('location: pelanggan.php');
}

?>