<?php
include "koneksi.php";
$id = -1;
if (isset($_GET['id'])){
    $id = $_GET['id'];
}
$sql = "DELETE FROM `karyawan` WHERE `id`=$id;";

if (mysqli_query($conn, $sql)) {
    header("location: karyawan.php");
}
exit();

if(isset($_POST['delete'])){ 
    $idh = $_POST['id_handphone'];

    $delete = mysqli_query($conn, "DELETE FROM handphone WHERE id_handphone='$idh'"); 

    if($delete){ 
       
        header('location:index.php');
    }else{ 
        echo 'gagal'; 
       
    }
}
