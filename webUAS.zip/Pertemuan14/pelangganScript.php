<?php
include('koneksi.php');

function get_data_pelanggan() {
    $query = "SELECT * FROM `pelanggan`";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return mysqli_fetch_all($sql);
}

function get_data_pelanggan_by_id($id) {
    $query = "SELECT * FROM `pelanggan` where `id`= $id;";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return mysqli_fetch_row($sql);
}

function save_data_pelanggan($nama,  $alamat, $nomor) {
    $result = mysqli_query($GLOBALS['conn'], "INSERT INTO `pelanggan` (`id`, `nama_pelanggan`,  `alamat`, `no_hp`) VALUES(NULL, '$nama',  '$alamat', '$nomor');");

    if($result) {
        return true;
    }else{
        return false;
    }
}

function update_data_pelanggan($id, $nama, $alamat, $nomor) {
  $result = mysqli_query($GLOBALS['conn'], "UPDATE `pelanggan` SET `nama_pelanggan`='$nama',`alamat`='$alamat',`no_hp`='$nomor' WHERE `id`='$id';");

  if($result) {
      return true;
  }else{
      return false;
  }
}

function delete_data_pelanggan($id) {
  $result = mysqli_query($GLOBALS['conn'], "DELETE FROM `pelanggan` WHERE `id`='$id';");

  if($result) {
      return true;
  }else{
      return false;
  }
}


?>