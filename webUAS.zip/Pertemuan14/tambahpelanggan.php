<?php
include('pelangganScript.php');


if(isset($_POST['simpan'])) {
    $status = save_data_pelanggan($_POST['nama'], $_POST['alamat'],  $_POST['hp']);

    if($status) {
        header('location: pelanggan.php');
    }
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Data</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-light">
        
        <img src="img/laundry.png">
            <a class="navbar-brand" href="dashboard.php">Aul Laundry</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="pelanggan.php">Pelanggan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="karyawan.php">Karyawan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="transaksi.php">Transaksi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">Logout</a>
                </li>
        
       
            </ul>
            </div>
        </div>
</nav>


  <div class="contrainer">
    <form method="POST" enctype="multipart/form-data">
      <div class="mb-3 row">
        <label for="nama" class="col-sm-2 col-form-label">Nama pelanggan</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="nama" name="nama">
        </div>
      </div>

      <div class="mb-3 row">
        <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
        <div class="col-sm-10">
          <textarea class="form-control" id="alamat" rows="3" name="alamat"></textarea>
        </div>
      </div>


      <div class="mb-3 row">
        <label for="hp" class="col-sm-2 col-form-label">No HP</label>
        <div class="col-sm-10">
          <input class="form-control" id="hp" rows="3" name="hp">
        </div>
      </div>

      
      <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
      <a href="pelanggan.php" class="btn btn-danger"> Kembali</a>
    </form>
  </div>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>