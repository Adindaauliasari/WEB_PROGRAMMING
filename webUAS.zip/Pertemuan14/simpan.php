<?php ?>

<!DOCTYPE html>
<html>
    <head>
        <title> adsi</title>
        <link rel = "stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <div class ="mainn">
            <div class="main2">
                <div class ="image"></div><br>

                <div class = "text"> 
                    <p> Data Berhasil Disimpan</p>

            
                </div>
            </div>	
            
    </div>
    </body>
</html>